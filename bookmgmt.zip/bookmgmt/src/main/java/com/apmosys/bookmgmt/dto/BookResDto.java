package com.apmosys.bookmgmt.dto;

public class BookResDto {

}
