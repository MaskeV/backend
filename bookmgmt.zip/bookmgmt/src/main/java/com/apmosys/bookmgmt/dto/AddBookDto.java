package com.apmosys.bookmgmt.dto;

public class AddBookDto {
	
	   private String name;
	
	   private String title;

	    private String author;

	    private String description;

	    private String category;

	    private String publisher;

	    private Integer publicationYear;

	    private String language;

	    private Integer quantity;

	    private Boolean available;

}
